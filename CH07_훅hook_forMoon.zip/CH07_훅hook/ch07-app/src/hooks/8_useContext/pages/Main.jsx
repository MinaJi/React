import React from 'react'
import Slider from '../ui/Slider'

function Main() {
  return (
    <div>Main Page
        <hr />
        <Slider />
    </div>
  )
}

export default Main