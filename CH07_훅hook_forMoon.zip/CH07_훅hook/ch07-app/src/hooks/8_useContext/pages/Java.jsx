import React from 'react'

function Java() {
  return (
    <div>JAVA Page
    <hr />
    <img src='/images/images_kkj53051000_post_5b6bc462-2d72-4776-a208-384fddc5941d_스크린샷 2022-01-18 오후 7.59.25.png' alt='JAVA' />
</div>
  )
}

export default Java