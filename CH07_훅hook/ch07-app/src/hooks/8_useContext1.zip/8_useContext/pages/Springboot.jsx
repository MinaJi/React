import React from 'react'

function Springboot() {
  return (
    <div>Springboot Page
    <hr />
    <img src='/images/img.jpeg' alt='Springboot' />
</div>
  )
}

export default Springboot