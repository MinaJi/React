import React from 'react'
import Header from '../layout/Header'
import Content from '../layout/Content'
import Footer from '../layout/Footer'

function Page() {
  return (
    <div>
        <Header />
        <Content />
        <Footer />
    </div>
  )
}

export default Page