import React from 'react'

function JavaScript() {
  return (
    <div>JavaScript Page
        <hr />
        <img src='/images/EzgdmaCQuT84bgDL4fhXZS.jpeg' alt='JavaScript' />
    </div>
  )
}

export default JavaScript