import React from 'react'

function Reacts() {
  return (
    <div>Reacts Page
        <hr />
        <img src='/images/deep-dive-react-fiber.png' alt='React' />
    </div>
  )
}

export default Reacts